// MATCH.JS
// Shows 8 buttons. You click one. Now, you try and find a match in 
// one of the remaining buttons. Like memory match.
//
//
// Note Match here is an object that consists of several objects.
//   Model: stores data
//   View: used for display 
//   Controller: decides what happens on key clicks
//
//   The run method is called FIRST.  It sets up everything by calling
//   helper functions.
//   First, it sets button values by calling assignButtonValues 
//   Next, it attaches button onclick handlers by calling attachHandlers
//   Next, it uses displayAll to return html to be displayed on browser
//

var Match = {

Model : {
  oldVal : undefined
},


View: {
  button1 : {id: "button1", type: "button", value: "", onclick:""},
  button2 : {id: "button2", type: "button", value: "", onclick:""},
  button3 : {id: "button3", type: "button", value: "", onclick:""},
  button4 : {id: "button4", type: "button", value: "", onclick:""},
  button5 : {id: "button5", type: "button", value: "", onclick:""},
  button6 : {id: "button6", type: "button", value: "", onclick:""},
  button7 : {id: "button7", type: "button", value: "", onclick:""},
  button8 : {id: "button8", type: "button", value: "", onclick:""},
  label : {id: "label", type: "label", value: "Click a Cell", onclick:""},
},

Controller: {
buttonHandler : function(that) {
 if (Match.Model.oldVal == undefined) {
   that.style.color = "blue";
   Match.Model.oldVal = that.value;
   console.log("Made it visible");
   document.getElementById("label").value = "Click a blank cell";
 }
 else if (that.value == Match.Model.oldVal) {
   document.getElementById("label").value = "Found Match";
   that.style.color = "blue";
   Match.Model.oldVal = undefined;
 }
 else {
   document.getElementById("label").value = "Not Matched";
 }

}

},

run : function() {
  Match.assignButtonValues();
  Match.attachHandlers();
  console.log(Match.displayAll());
  return Match.displayAll();
},

displayAll : function() {
  var s;
  s = "<table id=\"myTable\" border=2>"
  s += "<tr><td>";
  s += Match.displayElement(Match.View.button1);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button2);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button3);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button4);
  s += "</td></tr>";
  s += "<tr><td>";
  s += Match.displayElement(Match.View.button5);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button6);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button7);
  s += "</td><td>";
  s += Match.displayElement(Match.View.button8);
  s += "</td></tr>";
  s += "<tr><td colspan=\"4\">" + Match.displayElement(Match.View.label) + "</td></tr>";
  s += "</table>";
  return s;
},

displayElement : function (element) {
  var s = "<input ";
  s += " id=\"" + element.id + "\"";
  s += " type=\"" + element.type + "\"";
  s += " value= \"" + element.value + "\"";
  s += " onclick= \"" + element.onclick + "\"";
  if (element.type == "button") {
    s += " style=\"color:white\"";
  }
  s += ">";
  return s;

},

assignButtonValues: function () {
   let arrValues = [0,0,0,0,0,0,0,0];
   for (let i = 0; i < 8; i++) {
     let val = i%4 + 1;
       for (;;) {
          let idx = Math.floor(Math.random() * 8);
          console.log(idx);
          if (arrValues[idx] == 0) {
            arrValues[idx] = val;
            break;
          }
          else {
            continue;
          }
       }
   }

   for (var i = 1; i <= 8; i++) {
     Match.View["button" + i].value = arrValues[i-1];
   }
   // May be the case that some values are repeated!

},

attachHandlers : function() {
   for (var i = 1; i <= 8; i++) {
     Match.View["button" + i].onclick ="Match.Controller.buttonHandler(this)";
   }
},


} // end of Match;



